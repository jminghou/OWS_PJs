'use client';

import Image from 'next/image';
import Link from 'next/link';
import { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkSupersub from 'remark-supersub';
import rehypeRaw from 'rehype-raw';
import rehypeSlug from 'rehype-slug';
import { Content } from '@/types';
import { formatDateTime, getImageUrl, getGcsImageUrl } from '@/lib/utils';
import { extractToc, extractKeyTakeaways } from '@ows/content-kit';
import { absoluteUrl } from '@ows/site-kit';
import { ShareButtons as ShareButtons } from '@ows/site-kit';
import SaveArticleButton from '@/components/domain/membership/SaveArticleButton';

interface PostDetailContentProps {
  post: Content;
  relatedPosts?: Content[];
}

export default function PostDetailContent({ post, relatedPosts = [] }: PostDetailContentProps) {
  const [imgSrc, setImgSrc] = useState(getGcsImageUrl(post.featured_image || '', 'large'));

  // 抽出「重點整理」並從內文移除；目錄由移除後的內文產生（與 rehype-slug 的 id 對齊）
  const { takeaways, body } = extractKeyTakeaways(post.content);
  const toc = extractToc(body);
  // 分享用的是 canonical 網址（不含語言前綴/查詢字串）
  const shareUrl = absoluteUrl(`/posts/${post.slug}`);

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      {/* 主要內容區域 - 寬度 1000px (電腦版) */}
      <div className="mx-auto px-4 sm:px-6 w-full lg:w-[1080px]">
        <main>
            {/* 
              控制內容與外框的間距：修改下方 article 的 padding class
              目前設定：p-6 (手機), sm:p-8 (平板), lg:px-12 (電腦版左右間距)
              若要調整內文與框線的距離，請修改這裡的 padding 數值
            */}
            <article className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 sm:p-10 lg:px-20">
              {/* 1. 分類 - 麵包屑樣式 */}
              <div className="flex items-center gap-2 mb-3 text-sm text-gray-600">
                <span>
                  親紫專欄
                </span>
                {post.category && (
                  <>
                    <span className="text-gray-400">&gt;</span>
                    <span className="font-medium text-gray-900">
                      {post.category.name}
                    </span>
                  </>
                )}
              </div>

              {/* 2. 標題 (已移動到圖片上方並加大字體) */}
              <h1 className="text-3xl md:text-4xl lg:text-4xl font-bold text-gray-900 mb-4 leading-tight">
                {post.title}
              </h1>

              {/* 3. 圖片 */}
              {post.featured_image && (
                <div className="aspect-[16/9] relative overflow-hidden rounded-lg mb-8">
                  <Image
                    src={imgSrc}
                    alt={post.title}
                    fill
                    className="object-cover"
                    priority
                    sizes="(max-width: 1000px) 100vw, 1000px"
                    onError={() => {
                      const original = getImageUrl(post.featured_image);
                      if (imgSrc !== original) {
                        setImgSrc(original);
                      }
                    }}
                  />
                </div>
              )}

              {/* 4. 作者與日期 (取消瀏覽次數) */}
              <div className="flex flex-wrap items-center gap-4 text-xs text-gray-600 mb-8">
                {post.author && (
                  <span>
                    作者：
                    <Link
                      href={`/authors/${post.author.slug || post.author.username}`}
                      className="text-blue-600 hover:text-blue-800"
                    >
                      {post.author.name || post.author.username}
                    </Link>
                  </span>
                )}
                <span>發布於：{formatDateTime(post.published_at || post.created_at)}</span>
                {/* 取消瀏覽次數 */}
                {post.likes_count > 0 && (
                  <span>讚：{post.likes_count}</span>
                )}
              </div>

              {/* 5. 文章摘要 (字級縮小) */}
              {post.summary && (
                <div className="bg-gray-50 rounded-lg p-4 mb-8">
                  <h2 className="text-sm font-bold text-gray-900 mb-2">文章摘要</h2>
                  <p className="text-sm text-gray-700 leading-relaxed">{post.summary}</p>
                </div>
              )}

              {/* 重點整理 (TL;DR)：AI 最易整段抽取的格式 */}
              {takeaways.length > 0 && (
                <aside className="bg-amber-50 border border-amber-200 rounded-lg p-5 mb-8">
                  <h2 className="text-base font-bold text-amber-900 mb-3 flex items-center">
                    <span className="w-2.5 h-2.5 bg-amber-500 rounded-full mr-2"></span>
                    重點整理
                  </h2>
                  <ul className="list-disc pl-5 space-y-1.5 text-sm text-gray-800 leading-relaxed">
                    {takeaways.map((item, i) => (
                      <li key={i}>{item}</li>
                    ))}
                  </ul>
                </aside>
              )}

              {/* 目錄 (錨點對齊 rehype-slug 的標題 id)；長文才顯示 */}
              {toc.length >= 3 && (
                <nav aria-label="目錄" className="bg-white border border-gray-200 rounded-lg p-5 mb-8">
                  <h2 className="text-sm font-bold text-gray-900 mb-3">目錄</h2>
                  <ul className="space-y-1.5 text-sm">
                    {toc.map((item) => (
                      <li key={item.id} className={item.level === 3 ? 'pl-4' : ''}>
                        <a href={`#${item.id}`} className="text-gray-600 hover:text-blue-700 transition-colors">
                          {item.text}
                        </a>
                      </li>
                    ))}
                  </ul>
                </nav>
              )}

              {/* 6. 內文 (scroll-mt 讓錨點不被固定頁首遮住) */}
              <div className="prose prose-lg max-w-none [&_h2]:scroll-mt-24 [&_h3]:scroll-mt-24 [&_h4]:scroll-mt-24">
                {body && (
                  <ReactMarkdown
                    className="prose-content"
                    remarkPlugins={[remarkGfm, remarkSupersub]}
                    rehypePlugins={[rehypeRaw, rehypeSlug]}
                  >
                    {body}
                  </ReactMarkdown>
                )}
              </div>

              {/* 標籤 */}
              {post.tags && post.tags.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-8 pt-6 border-t border-gray-200">
                  <span className="text-sm font-medium text-gray-700 mr-2">標籤：</span>
                  {post.tags.map((tag) => (
                    <Link
                      key={tag.id}
                      href={`/posts?tag=${tag.name}`}
                      className="text-sm text-blue-600 hover:text-blue-800 bg-blue-50 hover:bg-blue-100 px-3 py-1 rounded-full transition-colors"
                    >
                      #{tag.slug}
                    </Link>
                  ))}
                </div>
              )}

              {/* 收藏 + 社群分享 */}
              <div className="mt-8 pt-6 border-t border-gray-200 flex items-center justify-between gap-4 flex-wrap">
                <SaveArticleButton contentId={post.id} />
                <ShareButtons url={shareUrl} title={post.title} />
              </div>
            </article>

            {/* 相關推薦（伺服器端渲染，進入初始 HTML 利於 AI/搜尋抓取與站內連結） */}
            {relatedPosts.length > 0 && (
              <section className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mt-8">
                <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
                  <span className="w-3 h-3 bg-amber-500 rounded-full mr-2"></span>
                  相關推薦
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {relatedPosts.map((related) => {
                    const img = related.cover_image || related.featured_image;
                    return (
                      <Link
                        key={related.id}
                        href={`/posts/${related.slug}`}
                        className="group flex gap-3 items-start rounded-lg hover:bg-gray-50 p-2 -m-2 transition-colors"
                      >
                        {img && (
                          <div className="relative w-20 h-20 flex-shrink-0 overflow-hidden rounded-md">
                            <Image
                              src={getGcsImageUrl(img, 'small')}
                              alt={related.title}
                              fill
                              sizes="80px"
                              className="object-cover"
                            />
                          </div>
                        )}
                        <div className="flex-1 min-w-0">
                          {related.category?.name && (
                            <span className="text-xs text-amber-700">{related.category.name}</span>
                          )}
                          <h3 className="text-sm font-semibold text-gray-900 leading-snug line-clamp-2 group-hover:text-blue-700">
                            {related.title}
                          </h3>
                          {related.summary && (
                            <p className="text-xs text-gray-500 mt-1 line-clamp-2">{related.summary}</p>
                          )}
                        </div>
                      </Link>
                    );
                  })}
                </div>
              </section>
            )}

        </main>
      </div>
    </div>
  );
}
