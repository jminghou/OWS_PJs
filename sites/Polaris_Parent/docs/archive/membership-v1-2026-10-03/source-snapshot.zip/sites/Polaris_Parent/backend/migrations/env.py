import logging
import os
from logging.config import fileConfig

from flask import current_app

from alembic import context

# =============================================================================
# 統一資料庫架構（見 ARCHITECTURE_UNIFIED_DB.md）
# 本站的表只在 blog/shop schema；版本表放 blog schema，與紫微系統的
# public.alembic_version 互不干擾。include_name 嚴格限定 autogenerate 只比對
# blog/shop，避免把 account/graph/public 既有表誤判為「待刪除」。
# =============================================================================
try:
    from packages.media_lib.config import SCHEMA_NAME as _MEDIA_LIB_SCHEMA
except Exception:  # pragma: no cover - 未安裝媒體庫時不擋 migration
    _MEDIA_LIB_SCHEMA = None

_OWNED_SCHEMAS = {s for s in (
    os.environ.get('OWS_BLOG_SCHEMA'),
    os.environ.get('OWS_SHOP_SCHEMA'),
    # media_lib 也是本站擁有的 schema（表由 packages/media_lib 定義，
    # 但實體存在本站的資料庫裡）。它原本沒列進來，導致 autogenerate 看不見
    # 媒體庫的表 —— 這就是為什麼整個 media_lib schema 從來沒進過 migration 鏈，
    # 而 Polaris 因此無法從零重建資料庫。見 scripts/check_schema_drift.py。
    _MEDIA_LIB_SCHEMA,
) if s}
_VERSION_TABLE_SCHEMA = os.environ.get('OWS_BLOG_SCHEMA') or None


def _include_name(name, type_, parent_names):
    """只讓 autogenerate 反射本站擁有的 schema（blog / shop / media_lib）。"""
    if type_ == 'schema':
        return name in _OWNED_SCHEMAS
    return True


# P5-C：平台資料表已移交 core/migrations（共用鏈）。
#
# 這裡要把它們從**站台鏈**的 autogenerate 排除，否則改一個 core 模型欄位時，
# `flask db migrate -d sites/.../migrations` 會把 migration 產在站台鏈裡 ——
# 那正是 C 要消滅的情況（每站各寫一份、各自漂移）。core 的變更只能進 core 鏈。
try:
    from core.backend_engine.migrations_manifest import PLATFORM_TABLES as _CORE_TABLES
except Exception:  # pragma: no cover - 匯入失敗時不擋 migration
    _CORE_TABLES = frozenset()
try:
    from packages.commerce.migrations_manifest import COMMERCE_TABLES as _COMMERCE_TABLES
except Exception:  # pragma: no cover
    _COMMERCE_TABLES = frozenset()
try:
    from packages.studio.migrations_manifest import STUDIO_TABLES as _STUDIO_TABLES
except Exception:  # pragma: no cover
    _STUDIO_TABLES = frozenset()
try:
    from packages.newsletter.migrations_manifest import NEWSLETTER_TABLES as _NEWSLETTER_TABLES
except Exception:  # pragma: no cover
    _NEWSLETTER_TABLES = frozenset()


# 第二期：blog.users 改為 view、RBAC 四表淘汰、member_profiles 由 SQL 自管，
# 這些不歸 Alembic 管理 → 從 autogenerate 排除（避免誤建/誤刪）。
_BLOG_SCHEMA_NAME = os.environ.get('OWS_BLOG_SCHEMA')
_BLOG_UNMANAGED_TABLES = {
    'users', 'roles', 'permissions', 'role_permissions', 'user_roles', 'member_profiles',
}


def _table_managed(schema, table_name):
    if schema not in _OWNED_SCHEMAS:
        return False
    if schema == _BLOG_SCHEMA_NAME and table_name in _BLOG_UNMANAGED_TABLES:
        return False
    # 平台表歸 core 鏈，站台鏈不碰
    if table_name in _CORE_TABLES:
        return False
    # 電商表歸 packages/commerce 鏈，站台鏈也不碰
    if table_name in _COMMERCE_TABLES:
        return False
    # Studio 表歸 packages/studio 鏈（與 core 表同住 blog schema，靠表名區分）
    if table_name in _STUDIO_TABLES:
        return False
    # Newsletter 表歸 packages/newsletter 鏈（同樣住在 blog schema）
    if table_name in _NEWSLETTER_TABLES:
        return False
    return True


def _include_object(object_, name, type_, reflected, compare_to):
    """只比對 blog/shop 中由 Alembic 管理的物件；media_lib / account / graph / public、
    以及 blog 的 view/RBAC/member_profiles 一律略過，確保不誤建或誤刪其他子系統的表。"""
    if type_ == 'table':
        return _table_managed(object_.schema, object_.name)
    tbl = getattr(object_, 'table', None)
    if tbl is not None:
        return _table_managed(tbl.schema, tbl.name)
    return True


# 本站擁有的 schema 設定（None 代表未設環境變數，退回單一 public 行為）
_SCHEMA_KWARGS = {
    'include_schemas': True,
    'version_table_schema': _VERSION_TABLE_SCHEMA,
    'include_name': _include_name,
    'include_object': _include_object,
} if _OWNED_SCHEMAS else {}

# this is the Alembic Config object, which provides
# access to the values within the .ini file in use.
config = context.config

# Interpret the config file for Python logging.
# This line sets up loggers basically.
fileConfig(config.config_file_name)
logger = logging.getLogger('alembic.env')


def get_engine():
    try:
        # this works with Flask-SQLAlchemy<3 and Alchemical
        return current_app.extensions['migrate'].db.get_engine()
    except (TypeError, AttributeError):
        # this works with Flask-SQLAlchemy>=3
        return current_app.extensions['migrate'].db.engine


def get_engine_url():
    try:
        return get_engine().url.render_as_string(hide_password=False).replace(
            '%', '%%')
    except AttributeError:
        return str(get_engine().url).replace('%', '%%')


# add your model's MetaData object here
# for 'autogenerate' support
# from myapp import mymodel
# target_metadata = mymodel.Base.metadata
config.set_main_option('sqlalchemy.url', get_engine_url())
target_db = current_app.extensions['migrate'].db

# other values from the config, defined by the needs of env.py,
# can be acquired:
# my_important_option = config.get_main_option("my_important_option")
# ... etc.


def get_metadata():
    if hasattr(target_db, 'metadatas'):
        return target_db.metadatas[None]
    return target_db.metadata


def run_migrations_offline():
    """Run migrations in 'offline' mode.

    This configures the context with just a URL
    and not an Engine, though an Engine is acceptable
    here as well.  By skipping the Engine creation
    we don't even need a DBAPI to be available.

    Calls to context.execute() here emit the given string to the
    script output.

    """
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url, target_metadata=get_metadata(), literal_binds=True,
        **_SCHEMA_KWARGS
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online():
    """Run migrations in 'online' mode.

    In this scenario we need to create an Engine
    and associate a connection with the context.

    """

    # this callback is used to prevent an auto-migration from being generated
    # when there are no changes to the schema
    # reference: http://alembic.zzzcomputing.com/en/latest/cookbook.html
    def process_revision_directives(context, revision, directives):
        if getattr(config.cmd_opts, 'autogenerate', False):
            script = directives[0]
            if script.upgrade_ops.is_empty():
                directives[:] = []
                logger.info('No changes in schema detected.')

    conf_args = current_app.extensions['migrate'].configure_args
    if conf_args.get("process_revision_directives") is None:
        conf_args["process_revision_directives"] = process_revision_directives

    connectable = get_engine()

    with connectable.connect() as connection:
        # 版本表若被指到 blog 等自訂 schema，alembic 會在跑任何 migration **之前**先建
        # 版本表 —— 那時 baseline 裡的 CREATE SCHEMA 還沒執行，全新資料庫會直接失敗。
        # 既有站台的 schema 都已存在，這裡的 IF NOT EXISTS 對它們是 no-op。
        # 先查存在與否再建：Postgres 對 CREATE SCHEMA IF NOT EXISTS 仍會檢查資料庫的 CREATE
        # 權限，正式環境的應用角色（如 Polaris 的 blog_app）沒有這個權限，schema 明明存在
        # 也會被拒絕。只有全新資料庫（schema 真的不存在）才需要建。
        if _VERSION_TABLE_SCHEMA:
            exists = connection.exec_driver_sql(
                'SELECT 1 FROM information_schema.schemata WHERE schema_name = %s',
                (_VERSION_TABLE_SCHEMA,),
            ).first()
            if not exists:
                connection.exec_driver_sql(f'CREATE SCHEMA {_VERSION_TABLE_SCHEMA}')
            # 一定要結束這裡自動開啟的交易，否則接下來 alembic 的 migration 會跑在同一個
            # 交易裡而永遠不 commit（表建了又整個回滾）。
            connection.commit()

        context.configure(
            connection=connection,
            target_metadata=get_metadata(),
            **_SCHEMA_KWARGS,
            **conf_args
        )

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
