import { Metadata } from 'next';
import Link from 'next/link';
import { JsonLd } from '@ows/site-kit';
import { AuthorsSection as AuthorsSection } from '@ows/site-kit';
import { buildAboutPageJsonLd, buildStaticPageAlternates } from '@ows/site-kit';
import { authorApi } from '@/lib/api';
import type { Author } from '@/types';

// 從 i18n 訊息檔案載入翻譯
import zhTW from '@/i18n/messages/zh-TW.json';
import zhCN from '@/i18n/messages/zh-CN.json';
import en from '@/i18n/messages/en.json';
import ja from '@/i18n/messages/ja.json';

// 多語言訊息對應
const messages: Record<string, typeof zhTW> = {
  'zh-TW': zhTW,
  'zh-CN': zhCN,
  'en': en,
  'ja': ja,
};

// ISR：關於頁很少變動，但作者資料需偶爾刷新
export const revalidate = 3600;

interface PageProps {
  params: Promise<{ locale: string }>;
}

async function getAuthors(): Promise<Author[]> {
  try {
    const { authors } = await authorApi.getList();
    return authors;
  } catch {
    return [];
  }
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { locale } = await params;
  const t = messages[locale]?.aboutPage || messages['zh-TW'].aboutPage;
  return {
    title: t.title,
    description: t.description,
    alternates: buildStaticPageAlternates('/about', locale),
  };
}

export default async function LocaleAboutPage({ params }: PageProps) {
  const { locale } = await params;
  const t = messages[locale]?.aboutPage || messages['zh-TW'].aboutPage;
  const basePath = locale === 'zh-TW' ? '' : `/${locale}`;
  const authors = await getAuthors();

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <JsonLd data={buildAboutPageJsonLd({ title: t.title, description: t.description, locale })} />
      <div className="prose prose-lg max-w-none">
        {/* 個人故事區塊 */}
        <section className="mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-8 text-center">
            {t.aboutMe}
          </h1>
          <div className="bg-warm-50 rounded-lg p-8 mb-8">
            <p className="text-lg leading-relaxed text-gray-700">
              {t.story}
            </p>
          </div>
        </section>

        {/* 品牌故事區塊 */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">
            {t.siteOriginTitle}
          </h2>
          <div className="bg-brand-purple-50 rounded-lg p-8 mb-6">
            <div className="border-l-4 border-brand-purple-500 pl-6 italic text-brand-purple-700 text-xl mb-6">
              <p className="mb-2">
                {t.quote}
              </p>
              <p className="text-sm text-right text-gray-500">
                {t.quoteAuthor}
              </p>
            </div>
            <p className="text-lg leading-relaxed text-gray-700">
              {t.siteOrigin}
            </p>
          </div>
        </section>

        {/* 品牌理念區塊 */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">
            {t.missionTitle}
          </h2>
          <div className="bg-gray-50 rounded-lg p-8">
            <p className="text-lg leading-relaxed text-gray-700">
              {t.mission}
            </p>
          </div>
        </section>

        {/* 作者區塊（E-E-A-T） */}
        <AuthorsSection authors={authors} locale={locale} />

        {/* 品牌使命區塊 */}
        <section className="text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">
            {t.exploreTitle}
          </h2>
          <p className="text-lg text-gray-600 mb-8 whitespace-pre-line">
            {t.exploreDescription}
          </p>
          <div className="flex justify-center">
            <Link
              href={`${basePath}/contact`}
              className="inline-flex items-center px-8 py-4 bg-brand-purple-600 hover:bg-brand-purple-700 text-white font-medium rounded-lg transition-colors"
            >
              {t.contactBtn}
              <svg className="ml-2 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
              </svg>
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
}
